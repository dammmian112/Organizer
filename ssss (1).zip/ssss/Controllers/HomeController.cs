using Microsoft.AspNetCore.Mvc;
using ssss.Models;
using System;
using System.Diagnostics;
using System.Linq;

namespace ssss.Controllers
{
    public class HomeController : Controller
    {
        private readonly ApplicationDbContext _context;

        public HomeController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Index(DateTime? doKiedy)
        {
            DateTime deadlineDate = doKiedy ?? DateTime.Now.AddDays(3);

            var upcomingDeadlines = _context.Zadania
                .Where(z => !z.CzyZakonczone && z.NaKiedyZadanie <= deadlineDate)
                .OrderBy(z => z.NaKiedyZadanie)
                .ToList();

            ViewData["DeadlineDate"] = deadlineDate.ToString("yyyy-MM-dd");

            return View(upcomingDeadlines);
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
