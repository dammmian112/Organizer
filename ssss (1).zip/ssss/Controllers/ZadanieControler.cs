﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ssss.Models;
using System.Linq;

namespace ssss.Controllers
{
    public class ZadanieController : Controller
    {
        private readonly ApplicationDbContext _context;

        public ZadanieController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Edit(int id)
        {
            var zadanie = _context.Zadania.Find(id);
            if (zadanie == null)
            {
                return NotFound();
            }

            // Pobierz listę priorytetów
            ViewData["Priorities"] = new List<string> { "Ważne", "Mało ważne", "Średnio ważne" };

            return View(zadanie);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(int id, [Bind("ID,Tytul,Opis,Kategoria,Priorytet,Godzina,NaKiedyZadanie,DataUtworzenia,CzyZakonczone")] ZadanieModel zadanie)
        {
            if (id != zadanie.ID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(zadanie);
                    _context.SaveChanges();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ZadanieExists(zadanie.ID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(ListaZadan));
            }

            // Pobierz listę priorytetów
            ViewData["Priorities"] = new List<string> { "Ważne", "Mało ważne", "Średnio ważne" };

            return View(zadanie);
        }

        public IActionResult Details(int id)
        {
            var zadanie = _context.Zadania.FirstOrDefault(m => m.ID == id);
            if (zadanie == null)
            {
                return NotFound();
            }

            return View(zadanie);
        }


        private bool ZadanieExists(int id)
        {
            return _context.Zadania.Any(e => e.ID == id);
        }


        public IActionResult UtworzZadanie()
        {
            ViewData["Categories"] = new List<string> { "Szkoła", "Zakupy", "Praca", "Inne" };
            ViewData["Priorities"] = new List<string> { "Ważne", "Mało ważne", "Średnio ważne" };
            ViewData["Title"] = "Utwórz Zadanie";
            return View();
        }

        [HttpPost]
        public IActionResult UtworzZadanie(ZadanieModel zadanie)
        {
            if (ModelState.IsValid)
            {
                _context.Zadania.Add(zadanie);
                _context.SaveChanges();
                return RedirectToAction("ListaZadan");
            }
            ViewData["Categories"] = new List<string> { "Szkoła", "Zakupy", "Praca", "Inne" };
            ViewData["Priorities"] = new List<string> { "Ważne", "Mało ważne", "Średnio ważne" };
            return View(zadanie);
        }


        public IActionResult ListaZadan(string sortOrder)
        {
            ViewData["TytulSortParm"] = string.IsNullOrEmpty(sortOrder) ? "tytul_desc" : "";
            ViewData["PriorytetSortParm"] = sortOrder == "Priorytet" ? "priorytet_desc" : "Priorytet";
            ViewData["DataSortParm"] = sortOrder == "Date" ? "date_desc" : "Date";

            var zadania = from z in _context.Zadania where !z.CzyZakonczone select z;

            switch (sortOrder)
            {
                case "tytul_desc":
                    zadania = zadania.OrderByDescending(z => z.Tytul);
                    break;
                case "Priorytet":
                    zadania = zadania.OrderBy(z => z.Priorytet);
                    break;
                case "priorytet_desc":
                    zadania = zadania.OrderByDescending(z => z.Priorytet);
                    break;
                case "Date":
                    zadania = zadania.OrderBy(z => z.NaKiedyZadanie);
                    break;
                case "date_desc":
                    zadania = zadania.OrderByDescending(z => z.NaKiedyZadanie);
                    break;
                default:
                    zadania = zadania.OrderBy(z => z.Tytul);
                    break;
            }

            return View(zadania.ToList());
        }

        public IActionResult ZakonczoneZadania(string sortOrder)
        {
            ViewData["TytulSortParm"] = string.IsNullOrEmpty(sortOrder) ? "tytul_desc" : "";
            ViewData["PriorytetSortParm"] = sortOrder == "Priorytet" ? "priorytet_desc" : "Priorytet";
            ViewData["DataSortParm"] = sortOrder == "Date" ? "date_desc" : "Date";

            var zadania = from z in _context.Zadania where z.CzyZakonczone select z;

            switch (sortOrder)
            {
                case "tytul_desc":
                    zadania = zadania.OrderByDescending(z => z.Tytul);
                    break;
                case "Priorytet":
                    zadania = zadania.OrderBy(z => z.Priorytet);
                    break;
                case "priorytet_desc":
                    zadania = zadania.OrderByDescending(z => z.Priorytet);
                    break;
                case "Date":
                    zadania = zadania.OrderBy(z => z.NaKiedyZadanie);
                    break;
                case "date_desc":
                    zadania = zadania.OrderByDescending(z => z.NaKiedyZadanie);
                    break;
                default:
                    zadania = zadania.OrderBy(z => z.Tytul);
                    break;
            }

            return View(zadania.ToList());
        }

        [HttpPost]
        public IActionResult PrzeniesDoZakonczonych(int id)
        {
            var zadanie = _context.Zadania.Find(id);
            if (zadanie != null)
            {
                zadanie.CzyZakonczone = true;
                _context.SaveChanges();
            }
            return RedirectToAction("ListaZadan");
        }

        [HttpPost]
        public IActionResult PrzeniesDoAktywnych(int id)
        {
            var zadanie = _context.Zadania.Find(id);
            if (zadanie != null)
            {
                zadanie.CzyZakonczone = false;
                _context.SaveChanges();
            }
            return RedirectToAction("ZakonczoneZadania");
        }
        public IActionResult UtworzZadanieCyklicznie()
        {
            ViewData["Categories"] = new List<string> { "Szkoła", "Zakupy", "Praca", "Inne" };
            ViewData["Priorities"] = new List<string> { "Ważne", "Mało ważne", "Średnio ważne" };
            ViewData["Title"] = "Utwórz Zadanie Cyklicznie";
            return View();
        }

        [HttpPost]
        public IActionResult UtworzZadanieCyklicznie(ZadanieModel zadanie)
        {
            if (ModelState.IsValid)
            {
                DateTime currentDate = zadanie.StartDate;
                while (currentDate <= zadanie.EndDate.Value)
                {
                    if (IsSelectedDay(zadanie, currentDate.DayOfWeek))
                    {
                        var newZadanie = new ZadanieModel
                        {
                            Tytul = zadanie.Tytul,
                            Opis = zadanie.Opis,
                            Kategoria = zadanie.Kategoria,
                            Priorytet = zadanie.Priorytet,
                            Godzina = zadanie.Godzina,
                            NaKiedyZadanie = currentDate,
                            DataUtworzenia = DateTime.Now,
                            IsCykliczne = true,
                            IntervalDays = zadanie.IntervalDays,
                            EndDate = zadanie.EndDate,
                            IsMonday = zadanie.IsMonday,
                            IsTuesday = zadanie.IsTuesday,
                            IsWednesday = zadanie.IsWednesday,
                            IsThursday = zadanie.IsThursday,
                            IsFriday = zadanie.IsFriday,
                            IsSaturday = zadanie.IsSaturday,
                            IsSunday = zadanie.IsSunday,
                            StartDate = zadanie.StartDate
                        };
                        _context.Zadania.Add(newZadanie);
                    }
                    currentDate = currentDate.AddDays(1);
                }
                _context.SaveChanges();
                return RedirectToAction("ListaZadan");
            }
            ViewData["Categories"] = new List<string> { "Szkoła", "Zakupy", "Praca", "Inne" };
            ViewData["Priorities"] = new List<string> { "Ważne", "Mało ważne", "Średnio ważne" };
            return View(zadanie);
        }

        private bool IsSelectedDay(ZadanieModel zadanie, DayOfWeek dayOfWeek)
        {
            switch (dayOfWeek)
            {
                case DayOfWeek.Monday:
                    return zadanie.IsMonday;
                case DayOfWeek.Tuesday:
                    return zadanie.IsTuesday;
                case DayOfWeek.Wednesday:
                    return zadanie.IsWednesday;
                case DayOfWeek.Thursday:
                    return zadanie.IsThursday;
                case DayOfWeek.Friday:
                    return zadanie.IsFriday;
                case DayOfWeek.Saturday:
                    return zadanie.IsSaturday;
                case DayOfWeek.Sunday:
                    return zadanie.IsSunday;
                default:
                    return false;
            }
        }

        public IActionResult HistoriaZadan(string sortOrder)
        {
            ViewData["TytulSortParm"] = string.IsNullOrEmpty(sortOrder) ? "tytul_desc" : "";
            ViewData["PriorytetSortParm"] = sortOrder == "Priorytet" ? "priorytet_desc" : "Priorytet";
            ViewData["DataSortParm"] = sortOrder == "Date" ? "date_desc" : "Date";

            var zadania = from z in _context.Zadania where z.CzyZakonczone select z;

            switch (sortOrder)
            {
                case "tytul_desc":
                    zadania = zadania.OrderByDescending(z => z.Tytul);
                    break;
                case "Priorytet":
                    zadania = zadania.OrderBy(z => z.Priorytet);
                    break;
                case "priorytet_desc":
                    zadania = zadania.OrderByDescending(z => z.Priorytet);
                    break;
                case "Date":
                    zadania = zadania.OrderBy(z => z.NaKiedyZadanie);
                    break;
                case "date_desc":
                    zadania = zadania.OrderByDescending(z => z.NaKiedyZadanie);
                    break;
                default:
                    zadania = zadania.OrderBy(z => z.Tytul);
                    break;
            }

            return View(zadania.ToList());
        }



        public IActionResult Usun(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var zadanie = _context.Zadania.FirstOrDefault(m => m.ID == id);
            if (zadanie == null)
            {
                return NotFound();
            }

            return View(zadanie);
        }

        [HttpPost, ActionName("Usun")]
        [ValidateAntiForgeryToken]
        public IActionResult UsunPotwierdzone(int id)
        {
            var zadanie = _context.Zadania.Find(id);
            if (zadanie == null)
            {
                return NotFound();
            }

            _context.Zadania.Remove(zadanie);
            _context.SaveChanges();
            return RedirectToAction(nameof(ListaZadan));
        }

    }
}
