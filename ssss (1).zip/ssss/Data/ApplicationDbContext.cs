﻿using Microsoft.EntityFrameworkCore;

namespace ssss.Models
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }

        public DbSet<ZadanieModel> Zadania { get; set; }
    }
}
