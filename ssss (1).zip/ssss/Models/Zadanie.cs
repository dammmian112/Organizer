﻿using System;
using System.ComponentModel.DataAnnotations;

namespace ssss.Models
{
    public class ZadanieModel
    {
        [Key]
        public int ID { get; set; }

        [Required(ErrorMessage = "Tytuł jest wymagany")]
        public string? Tytul { get; set; }

        public string? Opis { get; set; }

        [Required]
        public string Kategoria { get; set; }

        public bool CzyZakonczone { get; set; }

        [Required(ErrorMessage = "Priorytet jest wymagany")]
        public string Priorytet { get; set; }

        public TimeSpan? Godzina { get; set; }

        public DateTime DataUtworzenia { get; set; } = DateTime.Now;

        [Required(ErrorMessage = "Data wykonania zadania jest wymagana")]
        public DateTime NaKiedyZadanie { get; set; }

        // Nowe właściwości dla zadań cyklicznych
        public bool IsCykliczne { get; set; }
        public int IntervalDays { get; set; }
        public DateTime? EndDate { get; set; }

        public bool IsMonday { get; set; }
        public bool IsTuesday { get; set; }
        public bool IsWednesday { get; set; }
        public bool IsThursday { get; set; }
        public bool IsFriday { get; set; }
        public bool IsSaturday { get; set; }
        public bool IsSunday { get; set; }
        public DateTime StartDate { get; set; }
    }
}
