using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ssss.Views.Zadanie
{
    public class ZakonczoneZadaniaModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
