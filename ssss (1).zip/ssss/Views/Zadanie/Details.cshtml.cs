using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ssss.Views.Zadanie
{
    public class DetailsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
