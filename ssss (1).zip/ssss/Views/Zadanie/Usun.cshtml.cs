using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ssss.Views.Zadanie
{
    public class UsunModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
